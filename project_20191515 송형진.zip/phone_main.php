<!DOCTYPE html>
<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>

<body>

<html>
	<head><title> 전화번호부 </title></head>
	<body><center><br><h2> 전화번호부 관리 프로젝트 </h2><hr><br>
		◆◇ 프로그램 순서 ◇◆<br><br>
	<form name= "f1" method="post" action = "phone_book.php">
	<table width= 400 border=0 bordercolor=#000000
	cellspacing=1 height = 180 bgcolor=#FFCCCC>
	<tr ><td width = 5%></td>
	<td> <br><b>1. 전화번호부 정보 입력 <br><br>
	2. phonebook 데이터베이스 저장 <br><br>
	3. 전화번호부 출력 <br><br>
	</td><td width=5%></td>
		</tr>
	</table><br>
	아래 버튼을 누르면 다음 페이지로 넘어갑니다. <br><br>
	<input type="submit" value =" ◆ 전화번호부 정보 입력하러 가기 ◆ ">
	</form>
	<form name= "f1-2" method="post" action = "table_print.php"><br>
	<input type="submit" value =" ◆ 결과창 보러가기 ◆ ">
	</form>
	</center>
	</body>
</html>
</body>

</html>