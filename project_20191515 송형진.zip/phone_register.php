<!DOCTYPE html>
<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>

<body>
<?php
	include_once('connect.php');
	$phonenumber = $_POST['phonenumber'];
	$registerdate = $_POST['registerdate'];
	$name = $_POST['name'];
	
	$sql = "insert into phonebook values ('$phonenumber',$registerdate,'$name')";
	
	if($conn->query($sql))
	{
		echo "<center><h3><br><br> 등록 완료. <br><br><hr><br>";
	}
	else
	{
		echo "<center><h3><br><br> 올바르지 않습니다. 다시 등록해 주세요. <br><br><hr><br> ".$conn->error;
	}
	echo "이동할 화면을 선택하세요. <br><br>";
	echo "■ ■ [ <a href='phone_book.php'> 전화번호부 입력</a> ] ";
	echo "[ <a href='table_print.php'> 결과화면</a> ] ■ ■</h3></center>" ;

?>
</body>
</html>