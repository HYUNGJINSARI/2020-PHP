<!DOCTYPE html>
<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>

<body>

<?php
	include_once('connect.php');
	echo "<br><h2><center> 전화번호부 </center></h2>";
	echo "<hr>";
	
	$sql = "select *from phonebook";	# sql 안의 테이블의 값을 가져옴.
	$result = $conn->query($sql);
	if($result->num_rows > 0) 
	{
		echo "<B> ★ 테이블 이름: phonebook </B><br><br>"; 
		
?>

	<table width='600' border='1' color='red' cellpadding='1'>
		<tr>
			<td bgcolor='#FFFF00'><B> 등록일시 </B></td>
			<td bgcolor='#FFFF00'><B> 이름 </B></td>
			<td bgcolor='#FFFF00'><B> 전화번호 </B></td>
		</tr>


<?php
	while($row=$result->fetch_assoc()){
?>
	
		<tr>
			<td bgcolor='#FFF000'><?=$row['registerdate']?></td>
			<td bgcolor='#FFF000'><?=$row['name']?></td>
			<td bgcolor='#FFF000'><?=$row['phonenumber']?></td>
		</tr>	
<?php
	}
?>
	</table>
<?php
	}
?>

	<body>
	◀◁ [ <a href="phone_book.php"> 전화번호부 입력 화면</a> ]으로 이동

	</body>

</html>